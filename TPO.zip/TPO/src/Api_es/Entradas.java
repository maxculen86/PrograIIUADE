package Api_es;

import java.io.BufferedReader;
import java.io.FileReader;

import Api_es.InfoServicio;

public class Entradas {
	public void archTexto() {
		try {
		      FileReader arch = new FileReader("@datos.csv");
		      BufferedReader buffer = new BufferedReader(arch);
		      InfoServicio [] lineas = new InfoServicio [20];
		      int tam = 0;
		      
		      
		      String linea;
		      while((linea = buffer.readLine()) != null) {
		    	  String [] campos = linea.split(";", 10);
		    	  
		    	  for (int i = 0; i< campos.length  ; i++)
		    		  System.out.print(campos[i] + " - ");
		    	  System.out.println(""); 
		    	  
		    	  if (buscarlinea(lineas, campos[0], tam) == tam && !campos[0].startsWith("linea")  ) {
		    		  lineas [tam] = new InfoServicio ();
		    		  lineas[tam].nroLinea = tam + 1;
		    		  lineas[tam].linea = campos[0];
		    		  tam++;
		    	  }
		    		  
		    	  System.out.println("Lista de lineas "); 
		    	  for (int i=0; i< tam; i++)
		    		  System.out.println(Integer.valueOf(lineas[i].nroLinea)  + " - " + lineas[i].linea);
		      }
		      arch.close();
		      
		    }
		    catch(Exception e) {
		      System.out.println("Excepcion leyendo archivo "+ "@datos.csv" + ": " + e);
		    }		

	}
	private int buscarlinea(InfoServicio [] lineas, String buscado, int tam) {
		int i = 0;
		while (i < tam && lineas[i].linea.compareTo(buscado) != 0)
			i++;
		return i;
	}

}
