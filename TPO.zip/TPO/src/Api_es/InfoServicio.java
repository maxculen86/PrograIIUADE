package Api_es;

public class InfoServicio {
	public int nroLinea;
	public String linea;
}
