package MisImplementaciones.Dinamica;

import MiApi.ConjuntoTDA;

public class Conjunto implements ConjuntoTDA {

	class Nodo {
		String id;
		Nodo sig;
	}

	Nodo elemento;

	public void InicializarConjunto() {
		elemento = null;
	}

	public boolean ConjuntoVacio() {

		return (elemento == null);
	}

	public void Agregar(String id) {
		if (!Pertenece(id)) {
			Nodo nuevo = new Nodo();
			nuevo.id = id;
			nuevo.sig = elemento;
			nuevo = elemento;
		}

	}

	public String Elegir() {

		return elemento.id;
	}

	public void Sacar(String id) {
		if (!ConjuntoVacio()) {
			if (elemento.id == id) {
				elemento = null;
			} else {
				Nodo aux = elemento;
				while (aux.sig != null && aux.id != id)
					aux = aux.sig;

				if (aux.sig != null)
					aux.sig = aux.sig.sig;
			}
		}
	}

	public boolean Pertenece(String id) {
		Nodo aux = elemento;
		while (aux != null && aux.id != id) {
			aux = aux.sig;
		}
		return (aux != null);
	}

}
