package MisMetodos;

import Api_es.Entradas;
import Api_es.InfoServicio;


public class FileReader {
	public void readFile() {
		Entradas fileReader = new Entradas();
		fileReader.archTexto();
	}
	public void getLinea() {
		Entradas fileReader = new Entradas();
		fileReader.archTexto() ;
	}
}
