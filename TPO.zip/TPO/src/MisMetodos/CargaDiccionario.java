package MisMetodos;

import MisImplementaciones.Dinamica.DiccionarioMultiple;
public class CargaDiccionario {
	public DiccionarioMultiple obetenerDiccionario() {
		return crearDiccionario();
	}

	private DiccionarioMultiple crearDiccionario() {
		DiccionarioMultiple diccionario = new DiccionarioMultiple();
		diccionario.Inicializar();
		diccionario.Agregar(file.getLinea, file.getEstaciones);
		return null;	
	}
}
