package MiApi;

public interface DiccionarioMultipleTDA {
	public void Inicializar();
	public void Agregar(String clave, String valor);
	public void Eliminar(String clave);
	void EliminarValor(String clave, String valor);
	ConjuntoTDA Claves();
	ConjuntoTDA Recuperar(String clave);
}
