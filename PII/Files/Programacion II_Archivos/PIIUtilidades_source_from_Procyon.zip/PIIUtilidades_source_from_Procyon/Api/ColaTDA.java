// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface ColaTDA
{
    void Acolar(final int p0);
    
    void Desacolar();
    
    int Primero();
    
    boolean ColaVacia();
    
    void InicializarCola();
}
