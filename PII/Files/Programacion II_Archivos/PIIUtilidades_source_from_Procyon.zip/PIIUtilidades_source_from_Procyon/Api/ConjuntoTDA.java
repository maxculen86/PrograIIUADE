// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface ConjuntoTDA
{
    void Agregar(final int p0);
    
    void Sacar(final int p0);
    
    boolean Pertenece(final int p0);
    
    int Elegir();
    
    boolean ConjuntoVacio();
    
    void InicializarConjunto();
}
