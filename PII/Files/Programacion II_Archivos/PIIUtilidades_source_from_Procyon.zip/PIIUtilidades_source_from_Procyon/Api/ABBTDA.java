// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface ABBTDA
{
    int Raiz();
    
    ABBTDA HijoIzq();
    
    ABBTDA HijoDer();
    
    boolean ArbolVacio();
    
    void InicializarArbol();
    
    void AgregarElem(final int p0);
    
    void EliminarElem(final int p0);
}
