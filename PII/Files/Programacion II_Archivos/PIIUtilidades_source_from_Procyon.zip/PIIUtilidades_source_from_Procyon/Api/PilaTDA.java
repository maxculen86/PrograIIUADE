// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface PilaTDA
{
    void Apilar(final int p0);
    
    void Desapilar();
    
    int Tope();
    
    boolean PilaVacia();
    
    void InicializarPila();
}
