// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface GrafoTDA
{
    void InicializarGrafo();
    
    void AgregarVertice(final int p0);
    
    void EliminarVertice(final int p0);
    
    ConjuntoTDA Vertices();
    
    void AgregarArista(final int p0, final int p1, final int p2);
    
    void EliminarArista(final int p0, final int p1);
    
    boolean ExisteArista(final int p0, final int p1);
    
    int PesoArista(final int p0, final int p1);
}
