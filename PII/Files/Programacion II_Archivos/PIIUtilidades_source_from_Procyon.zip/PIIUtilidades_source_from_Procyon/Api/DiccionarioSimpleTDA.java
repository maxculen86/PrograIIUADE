// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface DiccionarioSimpleTDA
{
    void InicializarDiccionario();
    
    void Agregar(final int p0, final int p1);
    
    void Eliminar(final int p0);
    
    int Recuperar(final int p0);
    
    ConjuntoTDA Claves();
}
