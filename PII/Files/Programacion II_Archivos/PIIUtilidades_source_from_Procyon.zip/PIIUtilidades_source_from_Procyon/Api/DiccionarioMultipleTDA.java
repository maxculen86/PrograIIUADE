// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface DiccionarioMultipleTDA
{
    void InicializarDiccionario();
    
    void Agregar(final int p0, final int p1);
    
    void Eliminar(final int p0);
    
    void EliminarValor(final int p0, final int p1);
    
    ConjuntoTDA Recuperar(final int p0);
    
    ConjuntoTDA Claves();
}
