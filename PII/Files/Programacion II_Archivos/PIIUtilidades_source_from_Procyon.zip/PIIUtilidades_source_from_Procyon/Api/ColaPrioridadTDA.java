// 
// Decompiled by Procyon v0.5.36
// 

package Api;

public interface ColaPrioridadTDA
{
    void AcolarPrioridad(final int p0, final int p1);
    
    void Desacolar();
    
    int Primero();
    
    boolean ColaVacia();
    
    void InicializarCola();
    
    int Prioridad();
}
