// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ConjuntoTDA;
import Api.DiccionarioSimpleTDA;

public class DiccionarioSimple implements DiccionarioSimpleTDA
{
    Nodo inicio;
    
    @Override
    public void InicializarDiccionario() {
        this.inicio = null;
    }
    
    @Override
    public void Agregar(final int clave, final int valor) {
        Nodo actual;
        for (actual = this.inicio; actual != null && actual.clave != clave; actual = actual.sig) {}
        if (actual != null) {
            actual.valor = valor;
        }
        else {
            final Nodo nuevo = new Nodo();
            nuevo.clave = clave;
            nuevo.valor = valor;
            nuevo.sig = this.inicio;
            this.inicio = nuevo;
        }
    }
    
    @Override
    public void Eliminar(final int clave) {
        Nodo actual = this.inicio;
        Nodo ant = null;
        while (actual != null && actual.clave != clave) {
            ant = actual;
            actual = actual.sig;
        }
        if (ant == null) {
            this.inicio = this.inicio.sig;
        }
        else {
            ant.sig = actual.sig;
        }
    }
    
    @Override
    public int Recuperar(final int clave) {
        Nodo actual;
        for (actual = this.inicio; actual.clave != clave; actual = actual.sig) {}
        return actual.valor;
    }
    
    @Override
    public ConjuntoTDA Claves() {
        final ConjuntoTDA claves = new Conjunto();
        claves.InicializarConjunto();
        for (Nodo actual = this.inicio; actual != null; actual = actual.sig) {
            claves.Agregar(actual.clave);
        }
        return claves;
    }
    
    class Nodo
    {
        int clave;
        int valor;
        Nodo sig;
    }
}
