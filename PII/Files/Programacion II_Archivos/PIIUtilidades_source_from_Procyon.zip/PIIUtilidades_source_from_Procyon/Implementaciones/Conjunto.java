// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ConjuntoTDA;

public class Conjunto implements ConjuntoTDA
{
    Nodo primer;
    
    @Override
    public void Agregar(final int valor) {
        if (this.primer == null) {
            final Nodo nuevo = new Nodo();
            nuevo.dato = valor;
            nuevo.sig = null;
            this.primer = nuevo;
        }
        else {
            Nodo actual;
            for (actual = this.primer; actual != null && actual.dato != valor; actual = actual.sig) {}
            if (actual == null) {
                final Nodo nuevo = new Nodo();
                nuevo.dato = valor;
                nuevo.sig = this.primer;
                this.primer = nuevo;
            }
            else {
                actual.dato = valor;
            }
        }
    }
    
    @Override
    public void Sacar(final int x) {
        if (this.primer != null) {
            if (this.primer.dato == x) {
                this.primer = this.primer.sig;
            }
            else {
                Nodo aux;
                for (aux = this.primer; aux.sig != null && aux.sig.dato != x; aux = aux.sig) {}
                if (aux.sig != null) {
                    aux.sig = aux.sig.sig;
                }
            }
        }
    }
    
    @Override
    public boolean Pertenece(final int x) {
        Nodo aux;
        for (aux = this.primer; aux != null && aux.dato != x; aux = aux.sig) {}
        return aux != null;
    }
    
    @Override
    public int Elegir() {
        return this.primer.dato;
    }
    
    @Override
    public boolean ConjuntoVacio() {
        return this.primer == null;
    }
    
    @Override
    public void InicializarConjunto() {
        this.primer = null;
    }
    
    class Nodo
    {
        int dato;
        Nodo sig;
    }
}
