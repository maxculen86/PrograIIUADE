// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.PilaTDA;

public class Pila implements PilaTDA
{
    Nodo ultimo;
    
    @Override
    public void Apilar(final int valor) {
        final Nodo nuevo = new Nodo();
        nuevo.dato = valor;
        nuevo.sig = this.ultimo;
        this.ultimo = nuevo;
    }
    
    @Override
    public void Desapilar() {
        this.ultimo = this.ultimo.sig;
    }
    
    @Override
    public int Tope() {
        return this.ultimo.dato;
    }
    
    @Override
    public boolean PilaVacia() {
        return this.ultimo == null;
    }
    
    @Override
    public void InicializarPila() {
        this.ultimo = null;
    }
    
    class Nodo
    {
        int dato;
        Nodo sig;
    }
}
