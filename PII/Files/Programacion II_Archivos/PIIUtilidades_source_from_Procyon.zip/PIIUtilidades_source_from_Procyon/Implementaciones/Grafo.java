// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ConjuntoTDA;
import Api.GrafoTDA;

public class Grafo implements GrafoTDA
{
    NodoVertice primerVertice;
    
    @Override
    public void InicializarGrafo() {
        this.primerVertice = null;
    }
    
    @Override
    public void AgregarVertice(final int v) {
        final NodoVertice nuevo = new NodoVertice();
        nuevo.vertice = v;
        nuevo.iniArista = null;
        nuevo.sigVertice = this.primerVertice;
        this.primerVertice = nuevo;
    }
    
    @Override
    public void EliminarVertice(final int v) {
        NodoVertice actual = this.primerVertice;
        NodoVertice ant = null;
        while (actual != null && actual.vertice != v) {
            ant = actual;
            actual = actual.sigVertice;
        }
        if (ant == null) {
            this.primerVertice = this.primerVertice.sigVertice;
        }
        else {
            ant.sigVertice = actual.sigVertice;
        }
    }
    
    @Override
    public ConjuntoTDA Vertices() {
        final ConjuntoTDA verts = new Conjunto();
        verts.InicializarConjunto();
        for (NodoVertice actualVert = this.primerVertice; actualVert != null; actualVert = actualVert.sigVertice) {
            verts.Agregar(actualVert.vertice);
        }
        return verts;
    }
    
    @Override
    public void AgregarArista(final int v1, final int v2, final int peso) {
        NodoVertice origen;
        for (origen = this.primerVertice; origen.vertice != v1; origen = origen.sigVertice) {}
        NodoVertice destino;
        for (destino = this.primerVertice; destino.vertice != v2; destino = destino.sigVertice) {}
        final NodoArista nuevo = new NodoArista();
        nuevo.peso = peso;
        nuevo.destino = destino;
        nuevo.sigArista = origen.iniArista;
        origen.iniArista = nuevo;
    }
    
    @Override
    public void EliminarArista(final int v1, final int v2) {
        NodoVertice origen;
        for (origen = this.primerVertice; origen.vertice != v1; origen = origen.sigVertice) {}
        NodoVertice destino;
        for (destino = this.primerVertice; destino.vertice != v2; destino = destino.sigVertice) {}
        NodoArista actualArista = origen.iniArista;
        NodoArista antArista = null;
        while (actualArista != null && actualArista.destino != destino) {
            antArista = actualArista;
            actualArista = actualArista.sigArista;
        }
        if (antArista == null) {
            origen.iniArista = origen.iniArista.sigArista;
        }
        else {
            antArista.sigArista = actualArista.sigArista;
        }
    }
    
    @Override
    public boolean ExisteArista(final int v1, final int v2) {
        NodoVertice origen;
        for (origen = this.primerVertice; origen.vertice != v1; origen = origen.sigVertice) {}
        NodoVertice destino;
        for (destino = this.primerVertice; destino.vertice != v2; destino = destino.sigVertice) {}
        NodoArista actualArista;
        for (actualArista = origen.iniArista; actualArista != null && actualArista.destino != destino; actualArista = actualArista.sigArista) {}
        return actualArista != null;
    }
    
    @Override
    public int PesoArista(final int v1, final int v2) {
        NodoVertice origen;
        for (origen = this.primerVertice; origen.vertice != v1; origen = origen.sigVertice) {}
        NodoVertice destino;
        for (destino = this.primerVertice; destino.vertice != v2; destino = destino.sigVertice) {}
        NodoArista actualArista;
        for (actualArista = origen.iniArista; actualArista.destino != destino; actualArista = actualArista.sigArista) {}
        return actualArista.peso;
    }
    
    class NodoVertice
    {
        int vertice;
        NodoArista iniArista;
        NodoVertice sigVertice;
    }
    
    class NodoArista
    {
        int peso;
        NodoVertice destino;
        NodoArista sigArista;
    }
}
