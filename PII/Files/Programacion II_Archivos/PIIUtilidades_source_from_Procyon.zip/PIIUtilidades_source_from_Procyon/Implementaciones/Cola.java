// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ColaTDA;

public class Cola implements ColaTDA
{
    Nodo primero;
    Nodo ultimo;
    
    @Override
    public void Acolar(final int valor) {
        final Nodo nuevo = new Nodo();
        nuevo.dato = valor;
        nuevo.sig = null;
        if (this.ultimo == null) {
            final Nodo nodo = nuevo;
            this.primero = nodo;
            this.ultimo = nodo;
        }
        else {
            this.ultimo.sig = nuevo;
            this.ultimo = nuevo;
        }
    }
    
    @Override
    public void Desacolar() {
        this.primero = this.primero.sig;
        if (this.primero == null) {
            this.ultimo = null;
        }
    }
    
    @Override
    public int Primero() {
        return this.primero.dato;
    }
    
    @Override
    public boolean ColaVacia() {
        return this.ultimo == null;
    }
    
    @Override
    public void InicializarCola() {
        final Nodo nodo = null;
        this.primero = nodo;
        this.ultimo = nodo;
    }
    
    class Nodo
    {
        int dato;
        Nodo sig;
    }
}
