// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ColaPrioridadTDA;

public class ColaPrioridad implements ColaPrioridadTDA
{
    Nodo MayPr;
    
    @Override
    public void AcolarPrioridad(final int x, final int prioridad) {
        Nodo actual = this.MayPr;
        Nodo ant = null;
        final Nodo nuevo = new Nodo();
        nuevo.dato = x;
        nuevo.prioridad = prioridad;
        if (this.MayPr == null || prioridad > this.MayPr.prioridad) {
            nuevo.sig = this.MayPr;
            this.MayPr = nuevo;
        }
        else {
            while (actual != null && prioridad <= actual.prioridad) {
                ant = actual;
                actual = actual.sig;
            }
            nuevo.sig = actual;
            ant.sig = nuevo;
        }
    }
    
    @Override
    public void Desacolar() {
        this.MayPr = this.MayPr.sig;
    }
    
    @Override
    public int Primero() {
        return this.MayPr.dato;
    }
    
    @Override
    public boolean ColaVacia() {
        return this.MayPr == null;
    }
    
    @Override
    public void InicializarCola() {
        this.MayPr = null;
    }
    
    @Override
    public int Prioridad() {
        return this.MayPr.prioridad;
    }
    
    class Nodo
    {
        int prioridad;
        int dato;
        Nodo sig;
    }
}
