// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ABBTDA;

public class ABB implements ABBTDA
{
    NodoABB arbol;
    
    @Override
    public int Raiz() {
        return this.arbol.valor;
    }
    
    @Override
    public ABBTDA HijoIzq() {
        return this.arbol.izq;
    }
    
    @Override
    public ABBTDA HijoDer() {
        return this.arbol.der;
    }
    
    @Override
    public boolean ArbolVacio() {
        return this.arbol == null;
    }
    
    @Override
    public void InicializarArbol() {
        this.arbol = null;
    }
    
    @Override
    public void AgregarElem(final int x) {
        if (this.arbol == null) {
            this.arbol = new NodoABB();
            (this.arbol.izq = new ABB()).InicializarArbol();
            (this.arbol.der = new ABB()).InicializarArbol();
            this.arbol.valor = x;
        }
        else if (this.arbol.valor > x) {
            this.arbol.izq.AgregarElem(x);
        }
        else if (this.arbol.valor < x) {
            this.arbol.der.AgregarElem(x);
        }
    }
    
    @Override
    public void EliminarElem(final int x) {
        if (this.arbol == null) {
            return;
        }
        if (this.arbol.valor == x) {
            if (this.arbol.der.ArbolVacio() && this.arbol.izq.ArbolVacio()) {
                this.arbol = null;
            }
            else if (!this.arbol.der.ArbolVacio()) {
                this.arbol.valor = this.menorDeMayores(this.arbol.der);
                this.arbol.der.EliminarElem(this.arbol.valor);
            }
            else if (!this.arbol.izq.ArbolVacio()) {
                this.arbol.valor = this.mayorDeMenores(this.arbol.izq);
                this.arbol.izq.EliminarElem(this.arbol.valor);
            }
        }
        else if (this.arbol.valor > x) {
            this.arbol.izq.EliminarElem(x);
        }
        else if (this.arbol.valor < x) {
            this.arbol.der.EliminarElem(x);
        }
    }
    
    private int menorDeMayores(final ABBTDA a) {
        if (a.HijoDer().ArbolVacio()) {
            return a.Raiz();
        }
        return this.menorDeMayores(a.HijoDer());
    }
    
    private int mayorDeMenores(final ABBTDA a) {
        if (a.HijoIzq().ArbolVacio()) {
            return a.Raiz();
        }
        return this.mayorDeMenores(a.HijoIzq());
    }
    
    class NodoABB
    {
        int valor;
        ABBTDA izq;
        ABBTDA der;
    }
}
