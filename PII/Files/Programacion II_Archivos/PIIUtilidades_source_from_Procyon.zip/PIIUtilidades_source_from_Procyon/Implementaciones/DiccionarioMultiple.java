// 
// Decompiled by Procyon v0.5.36
// 

package Implementaciones;

import Api.ConjuntoTDA;
import Api.DiccionarioMultipleTDA;

public class DiccionarioMultiple implements DiccionarioMultipleTDA
{
    NodoClave inicio;
    
    @Override
    public void InicializarDiccionario() {
        this.inicio = null;
    }
    
    @Override
    public void Agregar(final int clave, final int valor) {
        NodoClave actualCl;
        for (actualCl = this.inicio; actualCl != null && actualCl.clave != clave; actualCl = actualCl.sigClave) {}
        if (actualCl == null) {
            final NodoClave nuevaClave = new NodoClave();
            nuevaClave.clave = clave;
            nuevaClave.valores = new NodoValor();
            nuevaClave.valores.valor = valor;
            nuevaClave.valores.sigValor = null;
            nuevaClave.sigClave = this.inicio;
            this.inicio = nuevaClave;
        }
        else {
            NodoValor actualVal;
            for (actualVal = actualCl.valores; actualVal != null && actualVal.valor != valor; actualVal = actualVal.sigValor) {}
            if (actualVal == null) {
                final NodoValor nuevoValor = new NodoValor();
                nuevoValor.valor = valor;
                nuevoValor.sigValor = actualCl.valores;
                actualCl.valores = nuevoValor;
            }
        }
    }
    
    @Override
    public void Eliminar(final int clave) {
        NodoClave actualCl = this.inicio;
        NodoClave antCl = null;
        while (actualCl != null && actualCl.clave != clave) {
            antCl = actualCl;
            actualCl = actualCl.sigClave;
        }
        if (actualCl != null) {
            if (antCl == null) {
                this.inicio = this.inicio.sigClave;
            }
            else {
                antCl.sigClave = actualCl.sigClave;
            }
        }
    }
    
    @Override
    public ConjuntoTDA Recuperar(final int clave) {
        final ConjuntoTDA valores = new Conjunto();
        valores.InicializarConjunto();
        NodoClave actualCl;
        for (actualCl = this.inicio; actualCl != null && actualCl.clave != clave; actualCl = actualCl.sigClave) {}
        if (actualCl != null) {
            for (NodoValor actualVal = actualCl.valores; actualVal != null; actualVal = actualVal.sigValor) {
                valores.Agregar(actualVal.valor);
            }
        }
        return valores;
    }
    
    @Override
    public ConjuntoTDA Claves() {
        final ConjuntoTDA claves = new Conjunto();
        claves.InicializarConjunto();
        for (NodoClave actualCl = this.inicio; actualCl != null; actualCl = actualCl.sigClave) {
            claves.Agregar(actualCl.clave);
        }
        return claves;
    }
    
    @Override
    public void EliminarValor(final int clave, final int valor) {
        NodoClave actualCl = this.inicio;
        NodoClave antCl = null;
        while (actualCl != null && actualCl.clave != clave) {
            antCl = actualCl;
            actualCl = actualCl.sigClave;
        }
        if (actualCl != null) {
            NodoValor actualVal = actualCl.valores;
            NodoValor antVal = null;
            while (actualVal != null && actualVal.valor != valor) {
                antVal = actualVal;
                actualVal = actualVal.sigValor;
            }
            if (actualVal != null) {
                if (antVal == null) {
                    actualCl.valores = actualVal.sigValor;
                }
                else {
                    antVal.sigValor = actualVal.sigValor;
                }
            }
            if (actualCl.valores == null) {
                if (antCl == null) {
                    this.inicio = this.inicio.sigClave;
                }
                else {
                    antCl.sigClave = actualCl.sigClave;
                }
            }
        }
    }
    
    class NodoClave
    {
        int clave;
        NodoValor valores;
        NodoClave sigClave;
    }
    
    class NodoValor
    {
        int valor;
        NodoValor sigValor;
    }
}
